package com.chinasofti.service.admin;

import com.chinasofti.model.base.Att;
import com.chinasofti.pageModel.DataGrid;

public interface AttService {

	DataGrid datagrid(Att att);

}
